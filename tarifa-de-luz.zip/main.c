/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


    

int main(){
	int gasto;
	printf("Elige tu gasto:\n");
	printf("1.-Gasto menor: <1000 KW\n");
	printf("2.-Gasto medio: 1000-1850 KW\n");
	printf("3.-Gasto mayor: >1850 KW\n");
	scanf("%i", &gasto);
	
	if(gasto==1){
		printf("\nTu tarifa es: $1.2");
	}
	if(gasto==2){
		printf("\nTu tarifa es: $1");
	}
	if (gasto==3){
		printf("\nTu tarifa es: $0.9");
	}
	return 0;
}

    
