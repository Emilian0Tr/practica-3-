
#include<stdio.h>
#include<math.h>
#define C 2.997925*pow(10,10)

int main(){
	float masa, E;
	printf("escribe la masa(gr):\n");
	scanf("%f",&masa);
	E= masa*pow(C,2);
	printf("La energia producida en ergios:%.2f", E);
	return 0;
}


