/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


int main()
{
  #include<stdio.h>
#include<math.h>

int main(){
	char letra;
	printf("Escribe un caracter:\n");
	scanf("%c",&letra);
	
	if(letra=='a'){
		printf(" %c es una vocal", letra);
	}
	if(letra=='e'){
		printf(" %c es una vocal", letra);
	}
	if(letra=='i'){
		printf(" %c es una vocal", letra);
	}
	if(letra=='o'){
		printf(" %c es una vocal", letra);
	}
	if(letra=='u'){
		printf(" %c es una vocal", letra);
	}
	if(letra=='b'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='c'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='d'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='f'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='g'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='h'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='j'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='k'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='l'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='m'){
		printf(" %c no es una vocal", letra);
	}	
	if(letra=='n'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='p'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='q'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='r'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='s'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='t'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='v'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='w'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='x'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='y'){
		printf(" %c no es una vocal", letra);
	}
	if(letra=='z'){
		printf(" %c no es una vocal", letra);
	}



	return 0;
}
}
