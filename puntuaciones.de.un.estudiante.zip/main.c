 #include<stdio.h>

int main(){
	int i, calificacion1,calificacion2,calificacion3,calificacion4, promedio;
		printf("Escribe tus calificaciones entre 0 y 100:\n");
		printf("Escribir calificacion 1:\n");
		scanf("%i", &calificacion1);
		printf("Escribir calificacion 2:\n");
		scanf("%i", &calificacion2);
		printf("Escribir calificacion 3:\n");
		scanf("%i", &calificacion3);
		printf("Escribir calificacion 4:\n");
		scanf("%i", &calificacion4);
	
	promedio=(calificacion1+calificacion2+calificacion3+calificacion4)/4;
    if(promedio>=90){
        printf("Tu nota es: A");
    }
    if(promedio<90 && promedio>=80){
        printf("Tu nota es: B");
    }
    if(promedio<80 && promedio>=70){
        printf("Tu nota es: C");
    }
    if(promedio<70 && promedio>=60){
        printf("Tu nota es: D");
    }
    if(promedio<60){
        printf("Tu nota es: E");
    }
}

