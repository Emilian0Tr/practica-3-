#include<stdio.h>

void main() {
	char letra;

	printf("\nIntroduce una letra o vocal: ");
	scanf("%c",&letra);

	switch(letra) {
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':
			printf("\nMetiste una %c: ", letra);
			break;
		default:
			printf("\n %c No es vocal", letra);
			break;
	}
}